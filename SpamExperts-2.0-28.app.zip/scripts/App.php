<?php

class App
{
    const VERSION = "2.0-23";
}
