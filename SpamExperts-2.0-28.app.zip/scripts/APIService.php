<?php


class APIService
{
    /** @var $ssl bool */
    public $ssl;

    /** @var $hostname string */
    public $hostname;

    /** @var $username string */
    public $username;

    /** @var $password string */
    public $password;

}